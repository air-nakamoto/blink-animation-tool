# Sample Images for Blink Animation Tool

This folder contains sample images for testing the blink animation tool.

## Files:
- 01-eyes-open.png    : Eyes open (目を開いた状態)
- 02-half-open.png    : Half-open eyes (半開き)
- 03-eyes-closed.png  : Eyes closed (目を閉じた状態)

## How to use:
1. Download and extract this ZIP file
2. Go to the Blink Animation Tool
3. Upload these three images:
   - Upload "01-eyes-open.png" to "Eyes Open"
   - Upload "02-half-open.png" to "Half Open"
   - Upload "03-eyes-closed.png" to "Eyes Closed"
4. Click "Download" to generate your APNG animation

## Image specs:
- Format: PNG
- Size: 678×1086px (Bust portrait)
- Total: ~2.3MB

Enjoy creating your blink animations!
