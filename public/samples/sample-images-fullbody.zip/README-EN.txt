━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Blink Animation PNG Tool
  Sample Images (Full Body)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This sample image set contains three images needed to create
a blink animation.

【Contents】
  • Eyes open image (01-eyes-open-fullbody.png)
  • Half-open eyes image (02-half-open-fullbody.png)
  • Eyes closed image (03-eyes-closed-fullbody.png)

【How to Use】
  1. Upload these three images to the tool
  2. Preview the animation
  3. Select your preferred emotion preset
  4. Download the APNG file

【About These Images】
  These sample images were created with the AI "Nano banana".

  You are free to use these images.
  (Commercial use OK • Modification OK • No credit required)

【Image Specs】
  • Format: PNG
  • Size: Full body portrait
  • Total: ~2.1MB

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Blink Animation PNG Tool
https://blink-animation-tool.vercel.app
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Japanese version: README.txt
