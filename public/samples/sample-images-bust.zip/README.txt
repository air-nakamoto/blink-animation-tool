━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Blink Animation PNG Tool
  Sample Images (Bust Portrait)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This sample image set contains three images needed to create
a blink animation.

【Contents】
  • 01-eyes-open.png    - Eyes open image
  • 02-half-open.png    - Half-open eyes image
  • 03-eyes-closed.png  - Eyes closed image

【How to Use】
  1. Upload these three images to the tool
  2. Preview the animation
  3. Select your preferred emotion preset
  4. Download the APNG file

【About These Images】
  These sample images were created with the AI "Nano banana".

  You are free to use these images.
  (Commercial use OK • Modification OK • No credit required)

【Image Specs】
  • Format: PNG
  • Size: 678×1086px (Bust portrait)
  • Total: ~2.3MB

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Blink Animation PNG Tool
https://blink-animation-tool.vercel.app
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

日本語版: README-ja.txt
